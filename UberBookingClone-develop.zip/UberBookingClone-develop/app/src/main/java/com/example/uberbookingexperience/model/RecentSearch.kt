package com.example.uberbookingexperience.model

data class RecentSearch(
  val location: String,
  val locationDesc: String
)
