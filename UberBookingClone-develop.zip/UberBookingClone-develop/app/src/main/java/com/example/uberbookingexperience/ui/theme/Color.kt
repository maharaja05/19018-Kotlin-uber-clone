package com.example.uberbookingexperience.ui.theme

import androidx.compose.ui.graphics.Color

val colorBlack = Color(0XFF000000)
val colorUberGrayBg = Color(0XFFF6F6F6)
val colorWhite = Color(0XFFFFFFFF)
val colorGrayLight = Color(0XFFBDBDBD)
val colorGrayExtraLight = Color(0XFFE0E0E0)
val colorLocationUI = Color(0XFF1565C0)
val colorGrayLighter = Color(0xFFEEEEEE)
val SelectedBgColor = Color(0xFFEDEDED)
val UnselectedBgColor = Color(0xFFF9F9F9)
val ClearIconTint = Color(0xFF777777)
val colorSubtitleGrey = Color(0xFFA4A4AC)